function doGet(e) {
  Logger.log(e);
  //console.log(e);
  Logger.log(e.parameter);
  if(e.parameter.page == 'home'){
    return HtmlService.createTemplateFromFile('index').evaluate();
  } else if(e.parameter.page == 'blog') {
    return HtmlService.createTemplateFromFile('blog').evaluate();
  } else if(e.parameter.page == 'write') {
    return HtmlService.createTemplateFromFile('write').evaluate();} 
    else if(e.parameter.page == 'contact') {
    return HtmlService.createTemplateFromFile('contact').evaluate();} 
    else {
    return HtmlService.createTemplateFromFile('index').evaluate();} 
  
}

function writeData(contents){
  const url = "https://docs.google.com/spreadsheets/d/1y3Sk4g2uA-zdYjmjods6QZUbanKrpw5ul8xsoDSBJhI/edit#gid=0";
  const ss = SpreadsheetApp.openByUrl(url);
  const ws = ss.getSheetByName('data');

  //Logger.log(title, content);
  ws.appendRow([contents.title, contents.content, new Date(), contents.section, contents.writer]);
}

function loadData(){
  const url = "https://docs.google.com/spreadsheets/d/1y3Sk4g2uA-zdYjmjods6QZUbanKrpw5ul8xsoDSBJhI/edit#gid=0";
  const ss = SpreadsheetApp.openByUrl(url);
  const ws = ss.getSheetByName('data');

  let data = ws.getRange(1,1, ws.getLastRow(),5).getValues();
  console.log(data);

  returnData = [];

  for(let index =0; index < data.length; index++) {
    returnData.push([data[index][0], data[index][1], String(data[index][2]), data[index][3],
    data[index][4]]);
  }

  return returnData; 
}

function include(filename){
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

function writeData2(content2){
  const url = "https://docs.google.com/spreadsheets/d/13qyJbiPrUy-bR_kwPQRky_DCLWiTLP2EwpqsWO8Rua8/edit#gid=0";
  const ss = SpreadsheetApp.openByUrl(url);
  const ws = ss.getSheetByName('todo');

  ws.appendRow([content2.list]);
}

function loadData2(){
  const url = "https://docs.google.com/spreadsheets/d/13qyJbiPrUy-bR_kwPQRky_DCLWiTLP2EwpqsWO8Rua8/edit#gid=0";
  const ss = SpreadsheetApp.openByUrl(url);
  const ws = ss.getSheetByName('todo');

  let data = ws.getRange(1,1, ws.getLastRow(), 1).getValues();
  return data;

}